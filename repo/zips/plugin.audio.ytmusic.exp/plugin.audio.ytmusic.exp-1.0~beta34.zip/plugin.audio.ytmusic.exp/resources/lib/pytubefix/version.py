__version__ = "8.12.1"

if __name__ == "__main__":
    print(__version__)